# Travlr Getaways

This Express application serves the Travlr Getaways customer website. The
Module 3 implementation uses an MVC structure and Handlebars to render trip
data from `data/trips.json` dynamically on the travel page.

## Install and run

From the project folder, run:

```powershell
npm install
npm start
```

Then open <http://localhost:3000/travel>.

## Verify the Module 2 flow

Run the automated smoke test:

```powershell
npm test
```

The test confirms that the Express application loads, the `/travel` route
returns a successful response, and Handlebars renders all JSON trip data with
the shared header and footer partials. It also verifies the trip images and
confirms that the view no longer contains hard-coded trip names.

## Module 3 MVC structure

```text
app.js
  -> app_server/routes/travel.js
  -> app_server/controllers/travel.js
     -> data/trips.json
  -> app_server/views/travel.hbs
     -> app_server/views/partials/header.hbs
     -> app_server/views/partials/footer.hbs
```
