const http = require('http');
const assert = require('assert/strict');
const fs = require('fs');
const path = require('path');
const app = require('../app');
const trips = require('../data/trips.json');

const templatePath = path.join(__dirname, '..', 'app_server', 'views', 'travel.hbs');

const escapeHandlebarsText = (value) => value
  .replaceAll('&', '&amp;')
  .replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;')
  .replaceAll("'", '&#x27;')
  .replaceAll('`', '&#x60;');

const request = (server, pathname) => new Promise((resolve, reject) => {
  const address = server.address();
  const options = {
    hostname: '127.0.0.1',
    port: address.port,
    path: pathname,
    method: 'GET'
  };

  const req = http.request(options, (res) => {
    let body = '';

    res.setEncoding('utf8');
    res.on('data', (chunk) => {
      body += chunk;
    });
    res.on('end', () => {
      resolve({ statusCode: res.statusCode, body });
    });
  });

  req.on('error', reject);
  req.end();
});

const run = async () => {
  const server = http.createServer(app);

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });

  try {
    const travel = await request(server, '/travel');
    const template = fs.readFileSync(templatePath, 'utf8');
    const sites = travel.body.match(/<ul id="sites">([\s\S]*?)<\/ul>/);

    assert.equal(travel.statusCode, 200);
    assert.match(travel.body, /<title>Travlr Getaways<\/title>/);
    assert.match(travel.body, /<h1>Travel<\/h1>/);
    assert.match(travel.body, /id="header"/);
    assert.match(travel.body, /id="footer"/);
    assert.doesNotMatch(travel.body, /{{[>#/]?/);
    assert.match(template, /{{#each trips}}/);
    assert.ok(sites, 'The rendered page must contain the trip list.');
    assert.equal((sites[1].match(/<li>/g) || []).length, trips.length);

    assert.equal(trips.length, 3);
    for (const trip of trips) {
      const renderedName = escapeHandlebarsText(trip.name);
      const image = await request(server, `/images/${trip.image}`);

      assert.equal(typeof trip.name, 'string');
      assert.equal(typeof trip.image, 'string');
      assert.equal(typeof trip.description, 'string');
      assert.match(trip.description, new RegExp(trip.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
      assert.match(travel.body, new RegExp(`<h2><a href="/travel">${renderedName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}<\\/a><\\/h2>`));
      assert.match(travel.body, new RegExp(`src="images/${trip.image.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}"`));
      assert.match(travel.body, new RegExp(`<p>${trip.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`));
      assert.doesNotMatch(template, new RegExp(trip.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
      assert.equal(image.statusCode, 200);
    }

    console.log('PASS: /travel rendered JSON trip data through MVC and Handlebars.');
  } finally {
    await new Promise((resolve, reject) => {
      server.close((error) => error ? reject(error) : resolve());
    });
  }
};

run().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
